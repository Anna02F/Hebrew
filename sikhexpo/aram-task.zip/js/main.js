$(document).ready(function () {
    $(window).load(function () {
        $('#js-loader').fadeOut("slow");
    });
});